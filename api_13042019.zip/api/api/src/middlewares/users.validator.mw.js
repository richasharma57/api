const apiErrors = require("../utils/error.utils");
const ApiError = require("../utils/error.utils");
const jsend = require("jsend");
const {
  errorResponse,
  validationResponse,
  successResponse
} = require("../utils/response.utils");
const HttpStatus = require("http-status-codes");

module.exports = {

  validate: (method) => {
    return (req, res, next) => {
      switch (method) {
        case 'authenticateUser':
          {
            req.checkBody("email", ApiError.MISSING_EMAIL_ID).notEmpty();
            req.checkBody("password", ApiError.MISSING_PASSWORD).isNumeric();
            var errors = req.validationErrors();

            if (errors) {
              var validationResult = {
                errors: []
              };
              errors.forEach(function (err) {
                validationResult.errors.push(err.msg);
              });
            }

            if (errors)
              return validationResponse(res, HttpStatus.OK, validationResult);
            else
              next();
          }
      }
    }
  }
}