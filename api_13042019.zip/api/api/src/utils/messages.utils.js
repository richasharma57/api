module.exports = {
  USER_CREATED: "User created successfully",
  TOKEN_GENERATED: "Token generated successfully" ,
  USER_DELETED: "User deleted successfully",
  USER_UPDATED: "User updated successfully",

}