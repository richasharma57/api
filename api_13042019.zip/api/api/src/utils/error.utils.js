module.exports = {
  ACCESS_DENIED: {
    code: 4000,
    message: "Access denied"
  },
  TOKEN_EXPIRED: {
    code: 4001,
    message: "Token expired"
  },
  UNKNOWN_ERROR: {
    code: 5000,
    message: "Unknown error !!!"
  },
  MISSING_EMAIL_ID: {
    code: 6000,
    message: "Invalid email"
  },
  MISSING_PASSWORD: {
    code: 6001,
    message: "Invalid password"
  },
  USER_DOESNT_EXIST: {
    code: 6002,
    message: "User doesn't exist"
  },
  USER_EMAIL_AlREADY_EXIST: {
    code: 6003,
    message: "User with given emailId already exist"
  },
  USER_MOBILE_NO_AlREADY_EXIST: {
    code: 6004,
    message: "User with given mobile no already exist"
  },
  USER_NOT_FOUND: {
    code: 6005,
    message: "User not found"
  },
  ROLES_NOT_FOUND: {
    code: 7000,
    message: "Roles not found"
  }
}