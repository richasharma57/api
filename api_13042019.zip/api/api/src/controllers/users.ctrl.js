const {
  logInfo,
  logError
} = require("../utils/logger.utils");
const {
  errorResponse,
  validationResponse,
  successResponse
} = require("../utils/response.utils");
const userRepo = require("../db/db.users");
const AuthDto = require("../dto/auth.dto");
const RegistrationDTO = require("../dto/registration.dto");
const ApiError = require("../utils/error.utils");
const Message = require("../utils/messages.utils");
const HttpStatus = require("http-status-codes");

module.exports = {

  authenticateUser: async (req, res, next) => {
    let user = new AuthDto(req.body.email, req.body.password);
    try {
      let status = await userRepo.authenticateUser(user)
      return status ?
        generateAuthToken(res, user, next) :
        validationResponse(res, HttpStatus.OK, ApiError.USER_DOESNT_EXIST);
    } catch (error) {
      return errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR, error);
    }
  },

  getAllUsers: async(req, res, next) => {
    //res.send("returning all users")
    try {
      const users = await userRepo.getAllUsers()
      return users ?
        successResponse(res, HttpStatus.OK, users) :
        errorResponse(res, HttpStatus.NOT_FOUND, ApiError.USER_NOT_FOUND);
     } catch (error) {
      
      return errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR, error);
    }
  },


  getUser: async(req, res, next) => {
    //res.send("returning users");
    try {
      const user = await userRepo.getUser(req.params.id);
      return user ?
        successResponse(res, HttpStatus.OK, user) :
        errorResponse(res, HttpStatus.NOT_FOUND, ApiError.USER_NOT_FOUND);
     } catch (error) {
      
      return errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR, error);
    }
  },

  registerUser: async (req, res, next) => {

    let registration_dto = parseRegistrationInputs(req);

    let status = await checkUserAlreadyExist(res, registration_dto);

    if (status === false) {
      let userId = await userRepo.insertUser(registration_dto)
        .catch(error => errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR,error));

      if (userId >= 1)
        return successResponse(res, HttpStatus.CREATED, Message.USER_CREATED);
    }
  },

  updateUser: async(req, res, next) => {
    //res.send("user updated successfully");
    let registration_dto = parseRegistrationInputs(req);
    let user = await userRepo.getUser(req.params.id)
    .catch(error => errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR,error));

      if(user)
      {
        
        if(registration_dto.email != user[0].email)
        {
          let status = await userRepo.checkUserEmailAlreadyExist(registration_dto)
          .catch(error => errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR,error));
      
          if (status === true)
            return validationResponse(res, HttpStatus.OK, ApiError.USER_EMAIL_AlREADY_EXIST);
      
        }
        if(registration_dto.mobile_no != user[0].mobile_no)
        {
          let status = await userRepo.checkUserMobileNoAlreadyExist(registration_dto)
          .catch(error => errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR,error));
      
          if (status === true)
            return validationResponse(res, HttpStatus.OK, ApiError.USER_MOBILE_NO_AlREADY_EXIST);
        }

        try {
          let affectedrows = await userRepo.updateUser(registration_dto,req.params.id);
          return affectedrows ?
            successResponse(res, HttpStatus.OK, Message.USER_UPDATED) :
            errorResponse(res, HttpStatus.NOT_FOUND, ApiError.USER_NOT_FOUND);
         } catch (error) {
          
          return errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR, error);
        }
      }
        
      
      return errorResponse(res, HttpStatus.NOT_FOUND, ApiError.USER_NOT_FOUND);
    

  },

  deleteUser: async(req, res, next) => {
    //res.send("user deleted successfully");
    try {
      let affectedrows = await userRepo.deleteUser(req.params.id);
      return affectedrows ?
        successResponse(res, HttpStatus.OK, Message.USER_DELETED) :
        errorResponse(res, HttpStatus.NOT_FOUND, ApiError.USER_NOT_FOUND);
     } catch (error) {
      
      return errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR, error);
    }
     
  }
};

const generateAuthToken = (res, user, next) => {
  res.user = user;
  return next();
}

const checkUserAlreadyExist = async (res, registration_dto) => {

  let status = await userRepo.checkUserEmailAlreadyExist(registration_dto)
    .catch(error => errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR,error));

  if (status === true)
    return validationResponse(res, HttpStatus.OK, ApiError.USER_EMAIL_AlREADY_EXIST);

  status = await userRepo.checkUserMobileNoAlreadyExist(registration_dto)
    .catch(error => errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR,error));

  if (status === true)
    return validationResponse(res, HttpStatus.OK, ApiError.USER_MOBILE_NO_AlREADY_EXIST);

  return status;
}

const parseRegistrationInputs = (req) => {
  return new RegistrationDTO(
    req.body.role_id,
    req.body.email,
    req.body.password,
    req.body.full_name,
    req.body.country_code,
    req.body.mobile_no,
    req.body.gender,
    req.body.date_of_birth,
    req.body.address_id,
    req.body.active_status,
    req.body.created_by,
    req.body.last_login
  );
};