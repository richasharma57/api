const {
  logInfo
} = require("../../utils/logger.utils");
const HttpStatus = require("http-status-codes");
const Message = require("../../utils/messages.utils");
const rolesRepo = require("../../db/uam/db.roles")
const {
  successResponse,
  errorResponse
} = require('../../utils/response.utils');
const ApiError = require("../../utils/error.utils")

module.exports = {
  getAllRoles: async (req, res) => {
    try {
      const roles = await rolesRepo.getAllRoles()
      return roles ?
        successResponse(res, HttpStatus.OK, roles) :
        errorResponse(res, HttpStatus.NOT_FOUND, ApiError.ROLES_NOT_FOUND);
    } catch (error) {
      return errorResponse(res, HttpStatus.INTERNAL_SERVER_ERROR, ApiError.UNKNOWN_ERROR, error);
    }
  }
}