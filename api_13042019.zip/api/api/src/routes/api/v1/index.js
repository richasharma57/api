const {
  Router
} = require("express");

const {
  verifyAuthToken,
  authenticateToken
} = require("../../../middlewares/users.auth.mw");
const router = Router();

//router.all("*", verifyAuthToken, authenticateToken);
router.use("/users", require("./users.route"));
router.use("/roles", require("./uam/roles.route"));

module.exports = router;