class User {
  constructor(id,role_id,email,password,full_name,country_code,mobile_no,gender,date_of_birth,address_id,active_status,created_by,last_login) {
    this.id = id,
    this.role_id = role_id,
    this.email = email,
    this.password = password,
    this.full_name = full_name,
    this.country_code = country_code,
    this.mobile_no = mobile_no,
    this.gender = gender,
    this.date_of_birth = date_of_birth,
    this.address_id = address_id,
    this.active_status = active_status,
    this.created_by = created_by,
    this.last_login = last_login
  }
}

module.exports = User;