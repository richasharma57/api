const db = require('../db.connection');
const Role = require("../../models/uam/role");
const {
  logError
} = require("../../utils/logger.utils");

module.exports = {
  getAllRoles: () => {
    return new Promise((resolve, reject) => {
      db.query("select id,name,description from roles", (error, results) => {
        if (error) {
          reject(error);
        } else if (results.length === 0)
          resolve(null);
        else {
          let roles = mapRoles(results);
          resolve(roles);
        }
      })
    });
  }
}

const mapRoles = (results) => {
  const roles = new Array();
  results
    .map(role => {
      description = roles.description ? role.description : '';
      roles.push(new Role(role.id, role.name, description));
    });
  return roles;
}