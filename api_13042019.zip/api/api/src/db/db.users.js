var db = require('./db.connection');
const User = require("../models/uam/user");

module.exports = {
  authenticateUser: ({
    email,
    password
  }) => {
    return new Promise((resolve, reject) => {
      db.query("select count(*) as user_count from users where email=? and password=?", [email, password], (error, results) => {
        if (error)
          reject(error);
        else if (results[0].user_count === 1)
          resolve(true);
        else
          resolve(false);
      })
    });
  },
  checkUserEmailAlreadyExist({
    email
  }) {
    return new Promise((resolve, reject) => {
      db.query("select count(*) as user_count from users where email=?", [email], (error, results) => {
        if (error)
          reject(error);
        else if (results[0].user_count >= 1)
          resolve(true);
        else
          resolve(false);
      })
    });
  },

  checkUserMobileNoAlreadyExist({
    mobile_no
  }) {
    return new Promise((resolve, reject) => {
      db.query("select count(*) as user_count from users where mobile_no=?", [mobile_no], (error, results) => {
        if (error)
          reject(error);
        else if (results[0].user_count >= 1)
          resolve(true);
        else
          resolve(false);
      })
    });
  },
  insertUser: (registration_dto) => {
    const {
      role_id,
      email,
      password,
      full_name,
      country_code,
      mobile_no,
      gender,
      date_of_birth,
      address_id,
      active_status,
      created_by,
      last_login
    } = registration_dto;

    return new Promise((resolve, reject) => {
      db.query("call sp_insert_user(?,?,?,?,?,?,?,?,?,?,?,?)",
        [role_id,
          email,
          password,
          full_name,
          country_code,
          mobile_no,
          gender,
          date_of_birth,
          address_id,
          active_status,
          created_by,
          last_login
        ],
        (error, results) => {
          if (error)
            reject(error);
          else
            resolve(results[0][0].userId);
        })
    })
  },
  getAllUsers: () => {
    return new Promise((resolve, reject) => {
      db.query("select id,role_id,email,password,full_name,country_code,mobile_no,gender,date_of_birth,address_id,active_status,created_by,last_login from users", (error, results) => {
        if (error) {
          console.log("11");
          reject(error);
        } else if (results.length === 0)
        { console.log("22");
          resolve(null);
        }
        else {
          let users = mapUsers(results);
          resolve(users);
        }
      })
    });
  },
  getUser :( id ) => {
    return new Promise((resolve, reject) => {
      db.query("select id,role_id,email,password,full_name,country_code,mobile_no,gender,date_of_birth,address_id,active_status,created_by,last_login from users where id=?", [id], (error, results) => {
        if (error) {
          reject(error);
        } else if (results.length === 0)
        { 
          resolve(null);
        }
        else {
          let user = mapUsers(results);
          resolve(user);
        }
      })
    });
  },
  deleteUser :( id ) => {
    return new Promise((resolve, reject) => {
      db.query("delete from users where id=?", [id], (error, results) => {
        if (error) {
          reject(error);
        } else if (results.affectedRows === 0)
        { 
          resolve(null);
        }
        else {
          resolve(results.affectedRows);
        }
      })
    });
  },
  updateUser: (registration_dto,id) => {
    const {
      role_id,
      email,
      password,
      full_name,
      country_code,
      mobile_no,
      gender,
      date_of_birth,
      address_id,
      active_status,
      created_by,
      last_login
    } = registration_dto;

    return new Promise((resolve, reject) => {
      db.query("update users set role_id = ?,email=?,password=?,full_name=?,country_code=?,mobile_no=?,gender=?,date_of_birth=?,address_id=?,active_status=?,created_by=?,last_login=? where id =?",
        [role_id,
          email,
          password,
          full_name,
          country_code,
          mobile_no,
          gender,
          date_of_birth,
          address_id,
          active_status,
          created_by,
          last_login,
          id
        ],
        (error, results) => {
          if (error)
            reject(error);
            else if (results.affectedRows === 0)
            { 
              resolve(null);
            }
            else {
              resolve(results.affectedRows);
            }
        })
    })
  }  

}

const mapUsers = (results) => {
  const users = new Array();
  results
    .map(user => {
      users.push(new User(user.id,user.role_id,user.email,user.password,
        user.full_name,user.country_code,user.mobile_no,user.gender,user.date_of_birth,user.address_id,
        user.active_status,user.created_by,user.last_login));
    });
  return users;
}